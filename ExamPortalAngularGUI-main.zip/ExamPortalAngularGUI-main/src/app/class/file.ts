export class File {

    file !: File;
}
