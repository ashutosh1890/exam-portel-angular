import { Userqna } from './userqna';

describe('Userqna', () => {
  it('should create an instance', () => {
    expect(new Userqna()).toBeTruthy();
  });
});
