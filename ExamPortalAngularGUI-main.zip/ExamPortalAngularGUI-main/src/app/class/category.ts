import { Quiz } from "./quiz";

export class Category {

    catid !: number;
    title !: String;
    description !: String;
    
  //  quizzes !: Set<Quiz>;
}
