import { Quiz } from "./quiz";

export class Question {

    quesid !: number;
    content !: String;
    image !: String;
    option1 !: String;
    option2 !: String;
    option3 !: String;
    option4 !: String;
    answer !: String;
    attempted !: number;

    // quiz !: Quiz;

     quiz:any = {
       
       
     }
}
