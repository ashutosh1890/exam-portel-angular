export class Userqna {

       quesid !: number;
        answer !: String;
  

        
}
