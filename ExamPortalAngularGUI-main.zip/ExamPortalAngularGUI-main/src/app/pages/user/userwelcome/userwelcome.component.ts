import { Component } from '@angular/core';

@Component({
  selector: 'userwelcome',
  templateUrl: './userwelcome.component.html',
  styleUrls: ['./userwelcome.component.css']
})
export class UserwelcomeComponent {

}
